# Common Stein kernels and the frozen-table obstruction

No Grothendieck endpoint changed. `PROOF.md` gives the full scope and proofs.

Main certified result: at epsilon=149/200, an explicit genuine cubic on 8,384
remote coordinates keeps EVERY convex mixture of the nineteen frozen row tables
strictly above 0.71335. This is a floor for a stored upper-table expression,
not a lower bound for the exact fibre potentials or original witness norm.

The package also rejects four previously feasible atomic laws by fusing pairs
of inherited Stein cuts, gives an exact two-Gram finite-feature formulation,
and contains six kernel-checked general Lean lemmas. The Riesz/Schur and Gaussian
applications are paper proofs; concrete floor data are externally directed checked.

## Replay

Requires Python 3 and python-flint (tested with the droplet runtime). Acceptance
uses no numpy, scipy or cvxpy. From any unrelated directory run:

    python3 -I /Users/alingalatan/workspaces/grothe/outputs/common-stein-20261023/package/replay.py

Replace that full prefix by the extracted package directory on another machine.
`replay.py` locates its inputs relative to its own absolute path and writes only
to a temporary directory. It replays all four old 671-cut laws, eight new
separators and corruption controls, singular-Gram checks, genuine cubic moments,
all nineteen directed table floors, both infinite gamma tails, and source/price
corruption rejection. `SHA256SUMS` binds every packaged file except itself.

## Lean and TeX

The live module is:
/Users/alingalatan/workspaces/grothe/Grothe/Lower/SteinFusion.lean

It imports the repository's existing Stein theorem. `proof/SteinFusion.lean`
is a byte-identical copy; `proof/AxiomsNew.lean` audits its six general results.
The new concrete numerical data are not claimed as Lean formalized.
`section.tex` is the byte-identical live manuscript insert, compiled in:
/Users/alingalatan/workspaces/grothe/handoff/research-third-decimal/handoff-2026-10-15/main.tex

## Discovery and limitations

All costly discovery ran on ssh yo with one BLAS thread. Discovery scripts and
JSONs are explicitly floating point. The joint 3,735-point law/kernel solve
improved one score by about 2.5e-6; it is not a continuous certificate. The
compressed SDP attempts failed numerically. None of these exploratory solves
is used to accept the table-floor theorem. Its prices are frozen exact rationals;
the original optimization output is unnecessary for acceptance.

The current witness is .745. No result is silently transferred to .7564.
Changing source profiles or retaining actual response compatibility can escape
the frozen-table floor. Completing only radial constraints cannot.
