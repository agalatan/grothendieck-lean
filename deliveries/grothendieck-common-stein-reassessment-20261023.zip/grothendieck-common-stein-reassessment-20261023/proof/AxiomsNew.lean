import Grothe.Lower.SteinFusion
#print axioms Grothe.Lower.SteinFusion.perspective_variance
#print axioms Grothe.Lower.SteinFusion.perspective_fusion_le
#print axioms Grothe.Lower.SteinFusion.unit_fusion_identity
#print axioms Grothe.Lower.SteinFusion.specCellG_unit_fusion
#print axioms Grothe.Lower.SteinFusion.unit_fusion_le
#print axioms Grothe.Lower.SteinFusion.common_kernel_projection
