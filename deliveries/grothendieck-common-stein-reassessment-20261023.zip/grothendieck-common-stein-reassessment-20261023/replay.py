#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, tempfile
p=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix="grothe-common-stein-replay-") as tmp:
    tmp=Path(tmp)
    def run(name,*args):
        subprocess.run([sys.executable,"-I",str(p/"tools"/name),*map(str,args)],cwd=tmp,check=True)
    for i in [7234,5661,1247,8701]:
        run("verify_radial_countermodel.py",p/f"data/radial-complete-{i}-exact.json")
    run("verify_common_stein.py",p/"data","--out",tmp/"exact.json")
    run("verify_genuine_table_floor.py",p/"data/source-rows.json",p/"data/genuine-price-config.json","--out",tmp/"floor.json")
    run("check_genuine_floor_controls.py",p/"tools/verify_genuine_table_floor.py",p/"data/source-rows.json",p/"data/genuine-price-config.json")
print("PASS complete isolated common-Stein and genuine-table-floor replay")
